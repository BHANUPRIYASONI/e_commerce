<?php $__env->startSection('content'); ?>
    <h1>Shop</h1>
    <div class="products">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="product">
                <h2><a href="<?php echo e(route('shop.show', $product->id)); ?>"><?php echo e($product->name); ?></a></h2>
                <p><?php echo e($product->description); ?></p>
                <p>Price: $<?php echo e($product->price); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bhanupriya_test\resources\views/shop/index.blade.php ENDPATH**/ ?>