<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <nav>
        <?php if(auth()->guard()->check()): ?>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
            <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                Logout
            </a>
        <?php endif; ?>
        <ul>
            <li><a href="<?php echo e(route('admin.users')); ?>">Users</a></li>
            <li><a href="<?php echo e(route('admin.customers')); ?>">Customers</a></li>
            <li><a href="<?php echo e(route('admin.vendors')); ?>">Vendors</a></li>
            <li><a href="<?php echo e(route('admin.products')); ?>">Products</a></li>
            <li><a href="<?php echo e(route('admin.orders')); ?>">Orders</a></li>
            <li><a href="<?php echo e(route('admin.transactions')); ?>">Transactions</a></li>
            <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
        </ul>
        
    </nav>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\bhanupriya_test\resources\views/layouts/admin.blade.php ENDPATH**/ ?>