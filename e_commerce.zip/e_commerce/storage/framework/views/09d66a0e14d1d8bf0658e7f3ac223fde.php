<?php $__env->startSection('content'); ?>
    <h1>Cart</h1>
    <?php if(Session::has('cart') && count(Session::get('cart')) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product['name']); ?></td>
                        <td>$<?php echo e($product['price']); ?></td>
                        <td>
                            <form action="<?php echo e(route('cart.remove', $product['id'])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit">Remove</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <a href="<?php echo e(route('checkout.index')); ?>">Proceed to Checkout</a>
    <?php else: ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bhanupriya_test\resources\views/cart/index.blade.php ENDPATH**/ ?>