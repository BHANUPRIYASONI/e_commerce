<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <form id="loginForm">
            <?php echo csrf_field(); ?>
            <div>
                <label for="email">Email</label>
                <input type="email" id="email" name="email">
            </div>
            <div>
                <label for="password">Password</label>
                <input type="password" id="password" name="password">
            </div>
            <button type="submit">Login</button>
        </form>
        <br>
        <div>
            <!-- Check if user is authenticated -->
                <p><a href="<?php echo e(route('register')); ?>">Create an account</a></p>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#loginForm').on('submit', function(event) {
                event.preventDefault();
                let formData = $(this).serialize();
                $.ajax({
                    url: "<?php echo e(route('login')); ?>",
                    method: "POST",
                    data: formData,
                    success: function(response) {
                        // window.location.href = '/profile';
                        window.location.href = response.routeName;
                    },
                    error: function(xhr) {
                        alert('Login failed! ' + xhr.responseText);
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\bhanupriya_test\resources\views/auth/login.blade.php ENDPATH**/ ?>