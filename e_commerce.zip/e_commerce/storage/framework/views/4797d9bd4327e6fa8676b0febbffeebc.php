<?php $__env->startSection('content'); ?>
    <h1><?php echo e($product->name); ?></h1>
    <p><?php echo e($product->description); ?></p>
    <p>Price: $<?php echo e($product->price); ?></p>

    <form method="POST" id="add_to_cart_form">
        
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
        <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
        <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
        <button type="submit">Add to Cart</button>
    </form>
<?php $__env->stopSection(); ?>

<script>
    $(document).ready(function() {
        $('#add_to_cart_form').on('submit', function(event) {
            event.preventDefault();
            let formData = new FormData(this);
            $.ajax({
                url: "<?php echo e(route('cart.add')); ?>",
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    alert('Card added successfully!');
                },
                error: function(xhr) {
                    alert('Cart addition failed! ' + xhr.responseText);
                }
            });
        });
    });
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bhanupriya_test\resources\views/shop/show.blade.php ENDPATH**/ ?>