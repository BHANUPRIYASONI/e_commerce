<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Admin Dashboard</h1>
        <p>Welcome to the Admin Dashboard!</p>
        <ul>
            
            
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bhanupriya_test\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>