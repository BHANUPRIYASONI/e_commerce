<nav>
    <ul>
        <li><a href="<?php echo e(route('shop.index')); ?>">Shop</a></li>
        <li><a href="<?php echo e(route('cart.index')); ?>">Cart</a></li>
        <li><a href="<?php echo e(route('checkout.index')); ?>">Checkout</a></li>
        <li><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
        <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
        <!-- Add other navigation links here -->
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\bhanupriya_test\resources\views/partials/navbar.blade.php ENDPATH**/ ?>