<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Profile</h2>
        <form id="profileForm" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div>
                <label for="name">Name</label>
                <input type="text" id="name" name="name" value="<?php echo e(auth()->user()->name); ?>">
            </div>
            <div>
                <label for="address">Address</label>
                <input type="text" id="address" name="address" value="<?php echo e(auth()->user()->address); ?>">
            </div>
            <div>
                <label for="contact">Contact</label>
                <input type="text" id="contact" name="contact" value="<?php echo e(auth()->user()->contact); ?>">
            </div>
            <div>
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo e(auth()->user()->email); ?>">
            </div>
            <div>
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="<?php echo e(auth()->user()->username); ?>">
            </div>
            <div>
                <label for="profile_picture">Profile Picture</label>
                <input type="file" id="profile_picture" name="profile_picture">
            </div>
            <div>
                <label for="dob">DOB</label>
                <input type="date" id="dob" name="dob" value="<?php echo e(auth()->user()->dob); ?>">
            </div>
            <button type="submit">Update Profile</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#profileForm').on('submit', function(event) {
                event.preventDefault();
                let formData = new FormData(this);
                $.ajax({
                    url: "<?php echo e(route('profile.update')); ?>",
                    method: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        alert('Profile updated successfully!');
                    },
                    error: function(xhr) {
                        alert('Profile update failed! ' + xhr.responseText);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bhanupriya_test\resources\views/profile.blade.php ENDPATH**/ ?>