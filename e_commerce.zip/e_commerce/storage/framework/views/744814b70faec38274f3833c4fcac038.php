<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Email</title>
</head>
<body>
    <h1>This is a test email.</h1>
    <p>If you are seeing this, your email configuration is working!</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\bhanupriya_test\resources\views/emails/test.blade.php ENDPATH**/ ?>