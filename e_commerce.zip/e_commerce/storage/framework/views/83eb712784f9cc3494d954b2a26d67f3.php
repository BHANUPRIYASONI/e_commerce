<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Register</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header" style="background-color: cornflowerblue;">Register</div>
                    <div class="card-body">
                        <form id="registerForm" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Full Name" required>
                            </div>
                            <div class="form-group">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" id="address" name="address" placeholder="Address" required>
                            </div>
                            <div class="form-group">
                                <label for="contact">Contact Number</label>
                                <input type="text" class="form-control" id="contact" name="contact" placeholder="Contact Number" required pattern="[0-9]{10}" title="Please enter a 10-digit number">
                                <small class="form-text text-muted">Please enter a 10-digit contact number.</small>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
                            </div>
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" name="username" placeholder="username" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password" minlength="8" required
                                    pattern="^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$"
                                    title="Password must be at least 8 characters long and contain at least one letter and one number">
                                <small class="form-text text-muted">Password must be at least 8 characters long and contain at least one letter and one number.</small>
                            </div>
                            <div class="form-group">
                                <label for="dob">DOB</label>
                                <input type="date" class="form-control" id="dob" name="dob" required>
                            </div>
                            <div class="form-group">
                                <label for="role">Role</label>
                                <select class="form-control" id="role" name="role" required>
                                    <option value="">Select Role</option>
                                    <option value="customer">Customer</option>
                                    <option value="vendor">Vendor</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="profile_picture">Profile Picture</label>
                                <input type="file" class="form-control-file" id="profile_picture" name="profile_picture">
                            </div>
                            <button type="submit" class="btn btn-primary" style="background-color: cornflowerblue;">Register</button>
                        </form>
                    </div>
                </div>
                <div class="mt-3 text-center">
                    <p>Already registered? <a href="<?php echo e(route('login')); ?>">Login</a></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


    <script>

        $(document).ready(function() {
            $('#registerForm').on('submit', function(event) {
                event.preventDefault();
                let formData = new FormData(this);
                $.ajax({
                    url: "<?php echo e(route('register')); ?>",
                    method: 'POST',
                    data: formData,
                    contentType: false,  // Ensure that contentType is set to false
                    processData: false,  // Ensure that processData is set to false
                    dataType: 'json',    // You can keep this if you expect a JSON response
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if(response.success){
                            alert('Registration successful!');
                            window.location.href = "<?php echo e(route('login')); ?>";
                        }
                    },
                    error: function(xhr) {
                        alert('Registration failed!');
                        window.location.href = "<?php echo e(route('register')); ?>";
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\e_commerce\e_commerce\resources\views/auth/register.blade.php ENDPATH**/ ?>