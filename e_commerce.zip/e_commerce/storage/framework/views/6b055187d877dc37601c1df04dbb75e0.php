<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header" style="background-color: cornflowerblue;">Login</div>
                    <div class="card-body">
                        <form id="loginForm">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <button type="submit" class="btn btn-primary" style="background-color: cornflowerblue;">Login</button>
                        </form>
                    </div>
                </div>
                <div class="mt-3 text-center">
                    <p>New user? <a href="<?php echo e(route('register')); ?>">Create an account</a></p>
                </div>
            </div>
        </div>
    </div>
    <script>

        $(document).ready(function() {
            $('#loginForm').on('submit', function(event) {
                event.preventDefault();
                let formData = $(this).serialize();
                $.ajax({
                    url: "<?php echo e(route('login')); ?>",
                    method: "POST",
                    data: formData,
                    success: function(response) {
                        if(response.success){
                            alert('Login Success!');
                            window.location.href = "<?php echo e(route('account.profile')); ?>";
                        }
                    },
                    error: function(xhr) {
                        alert('Invalid credentials or user not found!');
                        window.location.href = "<?php echo e(route('register')); ?>";
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\e_commerce\e_commerce\resources\views/auth/login.blade.php ENDPATH**/ ?>