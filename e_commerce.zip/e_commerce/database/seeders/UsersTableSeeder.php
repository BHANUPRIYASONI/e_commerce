<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        DB::table('users')->insert([
            'name' => 'Super Admin',
            'address' => '123 Admin Street',
            'contact' => '1234567890',
            'email' => 'admin@gmail.com',
            'username' => 'superadmin',
            'password' => Hash::make('12345678'),
            'profile_picture' => null,
            'dob' => '1980-01-01',
            'role' => 'superAdmin', // because we have only customer and vendor options for role
        ]);
    }
}
