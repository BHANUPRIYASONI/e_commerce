<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            //
            // // $table->string('name');
            // $table->text('address')->nullable();
            // $table->string('contact')->nullable();
            // // $table->string('email')->unique()->change(); // Ensure email is unique
            // $table->string('username')->unique()->nullable();
            // $table->string('password')->change(); // To make sure password column is string
            // $table->string('profile_picture')->nullable();
            // $table->date('dob')->nullable();
            // $table->enum('role', ['customer', 'vendor']);

            if (!Schema::hasColumn('users', 'address')) {
                $table->text('address')->nullable();
            }
            if (!Schema::hasColumn('users', 'contact')) {
                $table->string('contact')->nullable();
            }
            if (!Schema::hasColumn('users', 'username')) {
                $table->string('username')->unique()->nullable();
            }
            if (!Schema::hasColumn('users', 'profile_picture')) {
                $table->string('profile_picture')->nullable();
            }
            if (!Schema::hasColumn('users', 'dob')) {
                $table->date('dob')->nullable();
            }
            if (!Schema::hasColumn('users', 'role')) {
                $table->enum('role', ['customer', 'vendor', 'superAdmin']);
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            //
            Schema::table('users', function (Blueprint $table) {
                // // $table->dropColumn('name');
                // $table->dropColumn('address');
                // $table->dropColumn('contact');
                // $table->dropColumn('username');
                // $table->dropColumn('password');
                // $table->dropColumn('profile_picture');
                // $table->dropColumn('dob');
                // $table->dropColumn('role');

                if (Schema::hasColumn('users', 'address')) {
                    $table->dropColumn('address');
                }
                if (Schema::hasColumn('users', 'contact')) {
                    $table->dropColumn('contact');
                }
                if (Schema::hasColumn('users', 'username')) {
                    $table->dropColumn('username');
                }
                if (Schema::hasColumn('users', 'profile_picture')) {
                    $table->dropColumn('profile_picture');
                }
                if (Schema::hasColumn('users', 'dob')) {
                    $table->dropColumn('dob');
                }
                if (Schema::hasColumn('users', 'role')) {
                    $table->dropColumn('role');
                }
            });
        });
    }
};
