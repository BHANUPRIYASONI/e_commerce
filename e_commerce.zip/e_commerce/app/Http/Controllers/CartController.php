<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;


class CartController extends Controller
{
    //
    public function index()
    {
        $cart = Session::get('cart', []);
        return view('cart.index', compact('cart'));
    }

    public function add(Request $request)
    {
        // $product = $request->all();
        // $cart = Session::get('cart', []);
        // $cart[$product['id']] = $product;
        // Session::put('cart', $cart);

        // return redirect()->route('cart.index')->with('success', 'Product added to cart!');

        $product = $request->only(['id', 'name', 'price']);
        $cart = Session::get('cart', []);
        $cart[$product['id']] = $product;
        Session::put('cart', $cart);

        if ($request->ajax()) {
            return response()->json(['message' => 'Product added to cart!']);
        }

        return redirect()->route('cart.index')->with('success', 'Product added to cart!');

    }

    public function remove($id)
    {
        $cart = Session::get('cart', []);
        unset($cart[$id]);
        Session::put('cart', $cart);

        return redirect()->route('cart.index')->with('success', 'Product removed from cart!');
    }
}
