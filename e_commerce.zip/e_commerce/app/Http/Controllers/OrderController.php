<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\User;
use App\Models\Product;
use App\Models\Order;
use App\Models\Transaction;
use Illuminate\Support\Facades\Auth;


class OrderController extends Controller
{
    //
    public function index()
    {
        // Fetch the logged-in user
        $user = Auth::user();

        // Retrieve the user's orders
        $orders = $user->orders()->with('product', 'transactions')->get();

        // Pass the orders to the view
        return view('orders.index', compact('orders'));
    }

}
