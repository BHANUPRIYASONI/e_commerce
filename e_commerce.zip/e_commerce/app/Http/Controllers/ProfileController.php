<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class ProfileController extends Controller
{

    public function showProfileForm()
    {
        return view('profile');
    }

    public function updateProfile(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'address' => 'required|string|max:255',
            'contact' => 'required|string|max:10',
            'email' => 'required|string|email|max:255|unique:users,email,' . Auth::id(),
            'username' => 'required|string|max:255|unique:users,username,' . Auth::id(),
            'profile_picture' => 'nullable|image',
            'dob' => 'required|date',
            'role' => 'required|in:customer,vendor',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $user = Auth::user();

        $profilePicturePath = '';

        if ($request->hasFile('profile_picture')) {
            if ($user->profile_picture) {
                Storage::disk('public')->delete($user->profile_picture);
            }
            $profilePicturePath = $request->file('profile_picture')->store('profile_pictures','public');

            $user->profile_picture = $profilePicturePath;
        }

        $user = User::findOrFail(Auth::id());
        $user->name = $request->name;
        $user->address = $request->address;
        $user->contact = $request->contact;
        $user->email = $request->email;
        $user->username = $request->username;
        $user->profile_picture = $profilePicturePath;
        $user->dob = $request->dob;
        $user->role = $request->role;
        $user->update();

        return response()->json(['message' => 'Profile updated successfully!'], 200);
    }
}
