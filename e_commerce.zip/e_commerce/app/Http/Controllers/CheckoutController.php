<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

use App\Models\Order;
use App\Models\Transaction;
use Illuminate\Support\Facades\Auth;

class CheckoutController extends Controller
{
    //
    public function index()
    {
        $cart = Session::get('cart', []);
        return view('checkout.index', compact('cart'));
    }

    public function process(Request $request)
    {
        // Handle the order processing and payment logic here
        // For COD, just clear the cart and show a success message

            // Check if cart is empty
            if (!Session::has('cart') || count(Session::get('cart')) == 0) {
                return redirect()->route('shop.index')->with('error', 'Your cart is empty.');
            }

            // Get the cart items
            $cart = Session::get('cart');
            $total = array_sum(array_column($cart, 'price'));

             // Create the order
        foreach ($cart as $item) {
            $order = Order::create([
                'user_id' => Auth::id(),
                'product_id' => $item['id'],
                'quantity' => 1, // Assuming quantity is always 1 in this example
                'total_price' => $item['price'],
                'status' => 'completed',
            ]);

            // Create a new transaction
            Transaction::create([
                'user_id' => Auth::id(),
                'order_id' => $order->id,
                'amount' => $item['price'],
            ]);
        }


        Session::forget('cart');
        return redirect()->route('shop.index')->with('success', 'Order placed successfully!');
    }
}
