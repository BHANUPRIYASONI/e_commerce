<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Product;
use App\Models\Order;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

use Yajra\DataTables\Facades\DataTables;

class AdminController extends Controller
{

    public function index()
    {
        return view('admin.login');
    }

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        if (Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request->password])) {
            $user = Auth::guard('admin')->user();
            if($user && $user->role == 'superAdmin'){
                return response()->json(['success' => 'Login successful!'], 200);
            }else{
                Auth::guard('admin')->logout();
                return response()->json(['error' => 'Login failed!'], 401);
            }

        } else {
            return response()->json(['message' => 'Invalid credentials!'], 401);
        }
    }


    public function dashboard()
    {
        return view('admin.dashboard');
    }

    public function users()
    {
        // $users = User::all();
        // return view('admin.users', compact('users'));

        return view('admin.users');
    }

    public function getUsersData(Request $request)
    {
        if ($request->ajax()) {
            $data = User::latest()->get();
            // return DataTables::of($data)
            //     ->addIndexColumn()
            //     ->addColumn('action', function($row){
            //         $btn = '<a href="javascript:void(0)" class="edit btn btn-primary btn-sm">Edit</a>';
            //         $btn .= ' <a href="javascript:void(0)" class="delete btn btn-danger btn-sm">Delete</a>';
            //         return $btn;
            //     })
            //     ->rawColumns(['action'])
            //     ->make(true);
            return DataTables::of($data)
                ->addIndexColumn()->make(true);
        }
    }

    public function customers()
    {
        // $customers = User::where('role', 'customer')->get();
        // return view('admin.customers', compact('customers'));

        return view('admin.customers');

    }

    public function getCustomersData(Request $request)
    {
        if ($request->ajax()) {
            $data = User::where('role', 'customer')->get();
            return DataTables::of($data)
                ->addIndexColumn()->make(true);
        }
    }

    public function vendors()
    {
        // $vendors = User::where('role', 'vendor')->get();
        // return view('admin.vendors', compact('vendors'));
        return view('admin.vendors');
    }

    public function getVendorsData(Request $request)
    {
        if ($request->ajax()) {
            $data = User::where('role', 'vendor')->get();
            return DataTables::of($data)
                ->addIndexColumn()->make(true);
        }
    }

    public function products()
    {
        // $products = Product::all();
        // return view('admin.products', compact('products'));
        return view('admin.products');
    }

    public function getProductsData(Request $request)
    {
        if ($request->ajax()) {
            $data = Product::all();
            return DataTables::of($data)
                ->addIndexColumn()->make(true);
        }
    }

    public function orders()
    {
        $orders = Order::all();
        return view('admin.orders', compact('orders'));
    }

    public function transactions()
    {
        $transactions = Transaction::all();
        return view('admin.transactions', compact('transactions'));
    }

    public function logout(Request $request)
    {
        Auth::guard('admin')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('admin.login');
    }
}
