<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <div class="container">
        <h2>Register</h2>
        <form id="registerForm" enctype="multipart/form-data">
            @csrf
            <div>
                <label for="name">Name</label>
                <input type="text" id="name" name="name">
            </div>
            <div>
                <label for="address">Address</label>
                <input type="text" id="address" name="address">
            </div>
            <div>
                <label for="contact">Contact</label>
                <input type="text" id="contact" name="contact">
            </div>
            <div>
                <label for="email">Email</label>
                <input type="email" id="email" name="email">
            </div>
            <div>
                <label for="username">Username</label>
                <input type="text" id="username" name="username">
            </div>
            <div>
                <label for="password">Password</label>
                <input type="password" id="password" name="password">
            </div>
            <div>
                <label for="profile_picture">Profile Picture</label>
                <input type="file" id="profile_picture" name="profile_picture">
            </div>
            <div>
                <label for="dob">DOB</label>
                <input type="date" id="dob" name="dob">
            </div>
            <div>
                <label for="role">Role</label>
                <select id="role" name="role">
                    <option value="customer">Customer</option>
                    <option value="vendor">Vendor</option>
                </select>
            </div>
            <button type="submit">Register</button>
        </form>
        <br>
        <div>
            <!-- Check if user is authenticated -->
                <p>Already registered? <a href="{{ route('login') }}">Login</a></p>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#registerForm').on('submit', function(event) {
                event.preventDefault();
                let formData = new FormData(this);
                $.ajax({
                    url: "{{ route('register') }}",
                    method: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        alert('Registration successful!');
                    },
                    error: function(xhr) {
                        alert('Registration failed! ' + xhr.responseText);
                    }
                });
            });
        });
    </script>
</body>
</html>
