<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <nav>
        @auth
            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                @csrf
            </form>
            <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                Logout
            </a>
        @endauth
        <ul>
            <li><a href="{{ route('admin.users') }}">Users</a></li>
            <li><a href="{{ route('admin.customers') }}">Customers</a></li>
            <li><a href="{{ route('admin.vendors') }}">Vendors</a></li>
            <li><a href="{{ route('admin.products') }}">Products</a></li>
            <li><a href="{{ route('admin.orders') }}">Orders</a></li>
            <li><a href="{{ route('admin.transactions') }}">Transactions</a></li>
            <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
        </ul>
        {{-- <a href="{{ route('admin.dashboard') }}">Dashboard</a></li> --}}
    </nav>
    <div class="container">
        @yield('content')
    </div>
</body>
</html>
