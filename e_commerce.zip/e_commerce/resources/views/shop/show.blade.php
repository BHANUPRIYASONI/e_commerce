@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h1>{{ $product->name }}</h1>
                    <p>{{ $product->description }}</p>
                    <p>Price: ${{ $product->price }}</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-3">
        <div class="col-md-8">
            <form id="add_to_cart_form">
                @csrf
                <input type="hidden" name="id" value="{{ $product->id }}">
                <input type="hidden" name="name" value="{{ $product->name }}">
                <input type="hidden" name="price" value="{{ $product->price }}">
                <input type="hidden" name="description" value="{{ $product->description }}">
                <button type="submit" class="btn btn-primary">Add to Cart</button>
            </form>
        </div>
    </div>
</div>
@endsection


@section('scripts')
<script>
    $(document).ready(function() {
        $('#add_to_cart_form').on('submit', function(event) {
            event.preventDefault();
            let formData = new FormData(this);
            $.ajax({
                url: "{{ route('cart.add') }}",
                method: 'POST',
                data: formData,
                contentType: false,  // Ensure that contentType is set to false
                processData: false,  // Ensure that processData is set to false
                dataType: 'json',    // You can keep this if you expect a JSON response
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    alert('Card added successfully!');
                    window.location.href = "{{ route('cart.index') }}";
                },
                error: function(xhr) {
                    alert('Cart addition failed! ' + xhr.responseText);
                }
            });
        });
    });
</script>
@endsection
