@extends('layouts.app')

@section('content')
    <h1>{{ $product->name }}</h1>
    <p>{{ $product->description }}</p>
    <p>Price: ${{ $product->price }}</p>

    <form method="POST" id="add_to_cart_form">
        {{-- <form action="{{ route('cart.add') }}" method="POST"> --}}
        @csrf
        <input type="hidden" name="id" value="{{ $product->id }}">
        <input type="hidden" name="name" value="{{ $product->name }}">
        <input type="hidden" name="price" value="{{ $product->price }}">
        <button type="submit">Add to Cart</button>
    </form>
@endsection

<script>
    $(document).ready(function() {
        $('#add_to_cart_form').on('submit', function(event) {
            event.preventDefault();
            let formData = new FormData(this);
            $.ajax({
                url: "{{ route('cart.add') }}",
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    alert('Card added successfully!');
                },
                error: function(xhr) {
                    alert('Cart addition failed! ' + xhr.responseText);
                }
            });
        });
    });
</script>
