@extends('layouts.app')

@section('content')
    <h1>Shop</h1>
    <div class="products">
        @foreach($products as $product)
            <div class="product">
                <h2><a href="{{ route('shop.show', $product->id) }}">{{ $product->name }}</a></h2>
                <p>{{ $product->description }}</p>
                <p>Price: ${{ $product->price }}</p>
            </div>
        @endforeach
    </div>
@endsection
