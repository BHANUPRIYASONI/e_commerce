@extends('layouts.app')

@section('content')
    <h1>Shop</h1>
    <div class="products">
        <table class="table" id="products-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                @foreach($products as $product)
                    <tr>
                        <td><a href="{{ route('shop.show', $product->id) }}">{{ $product->name }}</a></td>
                        <td>{{ $product->description }}</td>
                        <td>${{ $product->price }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection

@section('scripts')
    <!-- Include jQuery and DataTables JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#products-table').DataTable();
        });
    </script>
@endsection
