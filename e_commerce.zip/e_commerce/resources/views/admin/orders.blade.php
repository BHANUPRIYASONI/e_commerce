@extends('layouts.admin')

@section('content')
    <div class="container">
        <h1>Orders</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>S.No.</th>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Total Price</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1;?>
                @foreach($orders as $order)
                    <tr>
                        <td>{{ $i }}</td>
                        <td>{{ $order->user->name }}</td>
                        <td>{{ $order->product->name }}</td>
                        <td>{{ $order->quantity }}</td>
                        <td>${{ $order->total_price }}</td>
                        <td>{{ $order->status }}</td>
                    </tr>
                    <?php $i++;?>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
