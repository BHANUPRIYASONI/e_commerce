{{-- @extends('layouts.admin')

@section('content')
    <div class="container">
        <h1>Products</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>S.No.</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Stock</th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1;?>
                @foreach($products as $product)
                    <tr>
                        <td>{{ $i }}</td>
                        <td>{{ $product->name }}</td>
                        <td>{{ $product->description }}</td>
                        <td>${{ $product->price }}</td>
                        <td>{{ $product->stock }}</td>
                    </tr>
                    <?php $i++;?>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection --}}

@extends('layouts.admin')

@section('content')
<div class="container">
    <h1>Products List</h1>
    <table class="table table-bordered" id="products-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Stock</th>
            </tr>
        </thead>
    </table>
</div>

<script type="text/javascript">
  $(document).ready(function() {
    $('#products-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ route('admin.products.data') }}",
        columns: [
            { data: 'id', name: 'id' },
            { data: 'name', name: 'name' },
            { data: 'description', name: 'description' },
            { data: 'price', name: 'price' },
            { data: 'stock', name: 'stock' },
        ]
    });
  });
</script>
@endsection


