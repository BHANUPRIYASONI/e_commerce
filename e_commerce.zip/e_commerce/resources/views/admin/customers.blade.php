{{-- @extends('layouts.admin')

@section('content')
    <div class="container">
        <h1>Customers</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>S.No.</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Address</th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1;?>
                @foreach($customers as $customer)
                    <tr>
                        <td>{{ $i }}</td>
                        <td>{{ $customer->name }}</td>
                        <td>{{ $customer->email }}</td>
                        <td>{{ $customer->contact }}</td>
                        <td>{{ $customer->address }}</td>
                    </tr>
                <?php $i++;?>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection --}}

@extends('layouts.admin')

@section('content')
<div class="container">
    <h1>Customers List</h1>
    <table class="table table-bordered" id="customers-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Created At</th>
                <th>Updated At</th>
            </tr>
        </thead>
    </table>
</div>

<script type="text/javascript">
  $(document).ready(function() {
    $('#customers-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ route('admin.customers.data') }}",
        columns: [
            { data: 'id', name: 'id' },
            { data: 'name', name: 'name' },
            { data: 'email', name: 'email' },
            { data: 'created_at', name: 'created_at' },
            { data: 'updated_at', name: 'updated_at' },
        ]
    });
  });
</script>
@endsection

