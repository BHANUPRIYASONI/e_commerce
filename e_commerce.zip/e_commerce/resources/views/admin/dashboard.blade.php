@extends('layouts.admin')

@section('content')
    <div class="container">
        <h1>Admin Dashboard</h1>
        <p>Welcome to the Admin Dashboard!</p>
        <ul>
            {{-- <li><a href="{{ route('admin.customers') }}">View Customers</a></li>
            <li><a href="{{ route('admin.vendors') }}">View Vendors</a></li> --}}
            {{-- <li><a href="{{ route('admin.products') }}">View Products</a></li>
            <li><a href="{{ route('admin.orders') }}">View Orders</a></li>
            <li><a href="{{ route('admin.transactions') }}">View Transactions</a></li> --}}
        </ul>
    </div>
@endsection
