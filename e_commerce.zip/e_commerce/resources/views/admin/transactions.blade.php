@extends('layouts.admin')

@section('content')
    <div class="container">
        <h1>Transactions</h1>
        <table class="table" id="transactions-table">
            <thead>
                <tr>
                    <th>S.No.</th>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1;?>
                @foreach($transactions as $transaction)
                    <tr>
                        <td>{{ $i }}</td>
                        <td>{{ $transaction->order_id }}</td>
                        <td>{{ $transaction->user->name }}</td>
                        <td>${{ $transaction->amount }}</td>
                    </tr>
                    <?php $i++;?>
                @endforeach
            </tbody>
        </table>
    </div>
    <!-- Include jQuery and DataTables JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#transactions-table').DataTable();
        });
    </script>
@endsection
