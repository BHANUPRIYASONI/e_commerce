{{-- @extends('layouts.admin')

@section('content')
    <div class="container">
        <h1>Vendors</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>S.No.</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Address</th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1;?>
                @foreach($vendors as $vendor)
                    <tr>
                        <td>{{ $i }}</td>
                        <td>{{ $vendor->name }}</td>
                        <td>{{ $vendor->email }}</td>
                        <td>{{ $vendor->contact }}</td>
                        <td>{{ $vendor->address }}</td>
                    </tr>
                    <?php $i++;?>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection --}}

@extends('layouts.admin')

@section('content')
<div class="container">
    <h1>Vendors List</h1>
    <table class="table table-bordered" id="vendors-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Created At</th>
                <th>Updated At</th>
            </tr>
        </thead>
    </table>
</div>

<script type="text/javascript">
  $(document).ready(function() {
    $('#vendors-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ route('admin.vendors.data') }}",
        columns: [
            { data: 'id', name: 'id' },
            { data: 'name', name: 'name' },
            { data: 'email', name: 'email' },
            { data: 'created_at', name: 'created_at' },
            { data: 'updated_at', name: 'updated_at' },
        ]
    });
  });
</script>
@endsection

