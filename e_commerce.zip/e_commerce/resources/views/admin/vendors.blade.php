@extends('layouts.admin')

@section('content')
    <div class="container">
        <h1>Vendors</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>S.No.</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Address</th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1;?>
                @foreach($vendors as $vendor)
                    <tr>
                        <td>{{ $i }}</td>
                        <td>{{ $vendor->name }}</td>
                        <td>{{ $vendor->email }}</td>
                        <td>{{ $vendor->contact }}</td>
                        <td>{{ $vendor->address }}</td>
                    </tr>
                    <?php $i++;?>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
