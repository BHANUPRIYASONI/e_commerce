@extends('layouts.app')

@section('content')
    <h1>Your Orders</h1>

    @if($orders->isEmpty())
        <p>You have no orders.</p>
    @else
        <table id="orders-table" class="display">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Product Name</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Quantity</th>
                    <th>Transaction ID</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                @foreach($orders as $order)
                    <?php $transaction = json_decode($order->transactions, true); ?>
                    <tr>
                        <td>{{ $order->id }}</td>
                        <td>{{ $order->product->name }}</td>
                        <td>{{ $order->product->description }}</td>
                        <td>{{ $order->status }}</td>
                        <td>{{ $order->quantity }}</td>
                        <td>{{ $transaction['id'] }}</td>
                        <td>${{ $transaction['amount'] }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
@endsection

@section('scripts')
    <!-- Include jQuery and DataTables JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#orders-table').DataTable();
        });
    </script>
@endsection
