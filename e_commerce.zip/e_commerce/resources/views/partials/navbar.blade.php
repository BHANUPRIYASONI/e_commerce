<nav>
    <ul>
        <li><a href="{{ route('shop.index') }}">Shop</a></li>
        <li><a href="{{ route('cart.index') }}">Cart</a></li>
        <li><a href="{{ route('checkout.index') }}">Checkout</a></li>
        <li><a href="{{ route('profile') }}">Profile</a></li>
        <li><a href="{{ route('logout') }}">Logout</a></li>
        <!-- Add other navigation links here -->
    </ul>
</nav>
