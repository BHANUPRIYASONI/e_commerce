@extends('layouts.app')

@section('content')
    <h1>Cart</h1>
    @if(Session::has('cart') && count(Session::get('cart')) > 0)
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach(Session::get('cart') as $product)
                    <tr>
                        <td>{{ $product['name'] }}</td>
                        <td>${{ $product['price'] }}</td>
                        <td>
                            <form action="{{ route('cart.remove', $product['id']) }}" method="POST">
                                @csrf
                                <button type="submit">Remove</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <a href="{{ route('checkout.index') }}">Proceed to Checkout</a>
    @else
        <p>Your cart is empty.</p>
    @endif
@endsection
