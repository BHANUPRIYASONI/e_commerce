@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <h1>Checkout</h1>
    @if(Session::has('cart') && count(Session::get('cart')) > 0)
        <div class="table-responsive">
            <h2>Cart Summary</h2>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach(Session::get('cart') as $product)
                        <tr>
                            <td>{{ $product['name'] }}</td>
                            <td>${{ $product['price'] }}</td>
                            <td>{{ $product['description'] }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <div class="table-responsive mt-4">
            <h2>User Details</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Contact</th>
                        <th>Address</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{{ auth()->user()->name }}</td>
                        <td>{{ auth()->user()->email }}</td>
                        <td>{{ auth()->user()->contact }}</td>
                        <td>{{ auth()->user()->address }}</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <form action="{{ route('checkout.process') }}" method="POST">
            @csrf
            <button type="submit" class="btn btn-primary mt-4">Place Order (COD)</button>
        </form>
    @else
        <p>Your cart is empty.</p>
    @endif
</div>
@endsection
