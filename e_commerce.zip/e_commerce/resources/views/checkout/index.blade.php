@extends('layouts.app')

@section('content')
    <h1>Checkout</h1>
    @if(Session::has('cart') && count(Session::get('cart')) > 0)
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                @foreach(Session::get('cart') as $product)
                    <tr>
                        <td>{{ $product['name'] }}</td>
                        <td>${{ $product['price'] }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <form action="{{ route('checkout.process') }}" method="POST">
            @csrf
            <button type="submit">Place Order (COD)</button>
        </form>
    @else
        <p>Your cart is empty.</p>
    @endif
@endsection
