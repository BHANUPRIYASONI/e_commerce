{{-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <div class="container">
        <h2>Profile</h2>
        <form id="profileForm" enctype="multipart/form-data">
            @csrf
            <div>
                <label for="name">Name</label>
                <input type="text" id="name" name="name" value="{{ auth()->user()->name }}">
            </div>
            <div>
                <label for="address">Address</label>
                <input type="text" id="address" name="address" value="{{ auth()->user()->address }}">
            </div>
            <div>
                <label for="contact">Contact</label>
                <input type="text" id="contact" name="contact" value="{{ auth()->user()->contact }}">
            </div>
            <div>
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="{{ auth()->user()->email }}">
            </div>
            <div>
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="{{ auth()->user()->username }}">
            </div>
            <div>
                <label for="profile_picture">Profile Picture</label>
                <input type="file" id="profile_picture" name="profile_picture">
            </div>
            <div>
                <label for="dob">DOB</label>
                <input type="date" id="dob" name="dob" value="{{ auth()->user()->dob }}">
            </div>
            <button type="submit">Update Profile</button>
        </form>
    </div>
    <script>
        $(document).ready(function() {
            $('#profileForm').on('submit', function(event) {
                event.preventDefault();
                let formData = new FormData(this);
                $.ajax({
                    url: "{{ route('profile.update') }}",
                    method: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        alert('Profile updated successfully!');
                    },
                    error: function(xhr) {
                        alert('Profile update failed! ' + xhr.responseText);
                    }
                });
            });
        });
    </script>
</body>
</html> --}}

@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>Profile</h2>
        <form id="profileForm" enctype="multipart/form-data">
            @csrf
            <div>
                <label for="name">Name</label>
                <input type="text" id="name" name="name" value="{{ auth()->user()->name }}">
            </div>
            <div>
                <label for="address">Address</label>
                <input type="text" id="address" name="address" value="{{ auth()->user()->address }}">
            </div>
            <div>
                <label for="contact">Contact</label>
                <input type="text" id="contact" name="contact" value="{{ auth()->user()->contact }}">
            </div>
            <div>
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="{{ auth()->user()->email }}">
            </div>
            <div>
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="{{ auth()->user()->username }}">
            </div>
            <div>
                <label for="profile_picture">Profile Picture</label>
                <input type="file" id="profile_picture" name="profile_picture">
            </div>
            <div>
                <label for="dob">DOB</label>
                <input type="date" id="dob" name="dob" value="{{ auth()->user()->dob }}">
            </div>
            <button type="submit">Update Profile</button>
        </form>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function() {
            $('#profileForm').on('submit', function(event) {
                event.preventDefault();
                let formData = new FormData(this);
                $.ajax({
                    url: "{{ route('profile.update') }}",
                    method: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        alert('Profile updated successfully!');
                    },
                    error: function(xhr) {
                        alert('Profile update failed! ' + xhr.responseText);
                    }
                });
            });
        });
    </script>
@endsection

