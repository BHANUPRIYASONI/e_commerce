@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>Profile</h2>
        <form id="profileForm" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Full Name" required value="{{ auth()->user()->name }}">
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" class="form-control" id="address" name="address" placeholder="Address" required value="{{ auth()->user()->address }}">
            </div>
            <div class="form-group">
                <label for="contact">Contact Number</label>
                <input type="text" class="form-control" id="contact" name="contact" placeholder="Contact Number" required pattern="[0-9]{10}" value="{{ auth()->user()->contact }}">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Email" required value="{{ auth()->user()->email }}">
            </div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="username" required value="{{ auth()->user()->username }}">
            </div>
            <div class="form-group">
                <label for="dob">DOB</label>
                <input type="date" class="form-control" id="dob" name="dob" name="dob" required value="{{ auth()->user()->dob }}">
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <select class="form-control" id="role" name="role" required>
                    <option value="customer" {{ auth()->user()->role == 'customer' ? 'selected' : '' }}>Customer</option>
                    <option value="vendor" {{ auth()->user()->role == 'vendor' ? 'selected' : '' }}>Vendor</option>
                </select>
            </div>
            <div class="form-group">
                <label for="profile_picture">Profile Picture</label>
                <input type="file" class="form-control-file" id="profile_picture" name="profile_picture" required>
            </div>
            <button type="submit" class="btn btn-primary" style="background-color: cornflowerblue;">Update Profile</button>
            <br>
            <br>
        </form>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function() {
            $('#profileForm').on('submit', function(event) {
                event.preventDefault();

                let formData = new FormData(this);

                $.ajax({
                    url: "{{ route('profile.update') }}",
                    method: 'POST',
                    data: formData,
                    contentType: false,  // Ensure that contentType is set to false
                    processData: false,  // Ensure that processData is set to false
                    dataType: 'json',    // You can keep this if you expect a JSON response
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        alert('Profile updated successfully!');
                    },
                    error: function(xhr) {
                        alert('Profile update failed! ' + xhr.responseText);
                    }
                });
            });

        });
    </script>
@endsection

