<?php

use Illuminate\Support\Facades\Route;


use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\OrderController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('auth.register');
});


// admin routes
    Route::group(['middleware', 'admin.guest', 'prefix' => 'admin'],function () {
        Route::get('/', [AdminController::class, 'index'])->name('admin.login');
        Route::post('/login', [AdminController::class, 'login'])->name('admin.login.post');
    });

    Route::group(['middleware' => 'admin.auth', 'prefix' => 'admin'], function () {
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
        Route::get('/customers', [AdminController::class, 'customers'])->name('admin.customers');
        Route::get('/customers/data', [AdminController::class, 'getCustomersData'])->name('admin.customers.data');
        Route::get('/vendors', [AdminController::class, 'vendors'])->name('admin.vendors');
        Route::get('/vendors/data', [AdminController::class, 'getVendorsData'])->name('admin.vendors.data');
        Route::get('/users', [AdminController::class, 'users'])->name('admin.users');
        Route::get('/users/data', [AdminController::class, 'getUsersData'])->name('admin.users.data');
        Route::get('/products', [AdminController::class, 'products'])->name('admin.products');
        Route::get('/products/data', [AdminController::class, 'getProductsData'])->name('admin.products.data');
        Route::get('/orders', [AdminController::class, 'orders'])->name('admin.orders');
        Route::get('/transactions', [AdminController::class, 'transactions'])->name('admin.transactions');
        Route::get('/logout', [AdminController::class, 'logout'])->name('admin.logout');
    });

// users routes
    Route::middleware(['auth.redirect'])->group(function () {
        Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
        Route::post('/register', [RegisterController::class, 'register']);

        Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
        Route::post('/login', [LoginController::class, 'login']);
    });

    Route::middleware(['user.auth'])->group(function () {
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('account.dashboard');
        Route::get('/profile', [ProfileController::class, 'showProfileForm'])->name('account.profile');
        Route::post('/profile', [ProfileController::class, 'updateProfile'])->name('profile.update');
        Route::get('/shop', [ShopController::class, 'index'])->name('shop.index');
        Route::get('/shop/{product}', [ShopController::class, 'show'])->name('shop.show');
        Route::post('/cart', [CartController::class, 'add'])->name('cart.add');
        Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
        Route::post('/cart/remove/{id}', [CartController::class, 'remove'])->name('cart.remove');
        Route::get('/checkout', [CheckoutController::class, 'index'])->name('checkout.index');
        Route::get('/orders', [OrderController::class, 'index'])->name('order.index');
        Route::post('/checkout', [CheckoutController::class, 'process'])->name('checkout.process');
        Route::get('/logout', [LoginController::class, 'logout'])->name('account.logout');
    });
